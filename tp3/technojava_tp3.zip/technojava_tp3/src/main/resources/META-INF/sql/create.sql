create table TODO
(
    ID_TODO BIGINT not null,
    DESCRIPTION VARCHAR(200) not null,
    primary key (ID_TODO)
);
