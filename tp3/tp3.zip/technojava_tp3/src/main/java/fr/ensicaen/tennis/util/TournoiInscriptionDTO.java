package fr.ensicaen.tennis.util;

import java.util.Date;

public class TournoiInscriptionDTO {
    public int codeTournoi;
    public String nomTournoi;
    public String lieuTournoi;
    public String dateTournoi;
    public String dateInscription;

    public TournoiInscriptionDTO() {
    }
}
