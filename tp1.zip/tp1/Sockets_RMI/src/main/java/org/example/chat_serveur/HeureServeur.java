package org.example.chat_serveur;

import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.*;
import java.util.Calendar;

public class HeureServeur extends UnicastRemoteObject implements InterfaceHeureServeur {
    public HeureServeur() throws RemoteException {
        super();
    }

    @Override
    public String getHeure() throws RemoteException {
        Calendar cal = Calendar.getInstance();
        return cal.getTime().toString();
    }

    public static void main(String[] args) {

        try {
            LocateRegistry.createRegistry(1099);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }

        try {
            HeureServeur serveur = new HeureServeur();
            Naming.rebind("rmi://localhost/HeureServeur", serveur);
            System.out.println("Time server online...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
