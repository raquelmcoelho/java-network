package org.example.chat_serveur;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.*;
import java.util.*;

public class ChatServeur extends UnicastRemoteObject implements InterfaceChatServeur {
    private Map<String, InterfaceChatClient> clients = new HashMap<>();

    public ChatServeur() throws RemoteException {
        super();
    }

    @Override
    public synchronized void connect(String pseudo, String url) throws RemoteException {
        try {
            InterfaceChatClient client = (InterfaceChatClient) Naming.lookup(url);
            clients.put(pseudo, client);
            System.out.println(pseudo + " connected.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public synchronized void disconnect(String pseudo) throws RemoteException {
        clients.remove(pseudo);
        System.out.println(pseudo + " disconnected.");
    }

    @Override
    public synchronized void broadcastMessage(Message msg) throws RemoteException {
        for (InterfaceChatClient client : clients.values()) {
            client.diffuseMessage(msg);
        }
    }

    public static void main(String[] args) {
        try {
            ChatServeur serveur = new ChatServeur();
            Naming.rebind("rmi://localhost/ChatServeur", serveur);
            System.out.println("Chat Server Online...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
