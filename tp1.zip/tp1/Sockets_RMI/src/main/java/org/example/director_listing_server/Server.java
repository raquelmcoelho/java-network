package org.example;

import java.io.*;
import java.net.*;

// TODO: thread
public class Server {
    public static void main(String[] args) throws IOException {
        final int port = 9092;
        ServerSocket serversock = null;

        try {
            serversock = new ServerSocket(port);
        } catch(IOException ioe) {
            System.out.println("Error on the server " + ioe);
            System.exit(1);
        }

        Socket service = null;
        System.out.println("Listening for connection on port: " + port);

        try {
            service = serversock.accept();
        } catch(IOException ioe) {
            System.out.println("Accept connection failed !");
            System.exit(1);
        }

        System.out.println("Connection successful");
        System.out.println("Waiting for data ...");
        BufferedReader input = new BufferedReader(new InputStreamReader(service.getInputStream()));
        PrintWriter output = new PrintWriter((service.getOutputStream()),true);

        readDir(input.readLine(), output);

        output.close();
        input.close();
        service.close();
        serversock.close();
    }

    public static void readDir(String dir, PrintWriter out) {
        File directory = new File(dir);
        String[] files = directory.list();

        out.println("Listing directory " + dir);
        if (files != null) {
            out.println(files.length + " files found:");
            for (String file : files) {
                out.println(file);
            }
        } else {
            System.out.println("Invalid directory name");
            out.println(-1);
        }
    }
}

