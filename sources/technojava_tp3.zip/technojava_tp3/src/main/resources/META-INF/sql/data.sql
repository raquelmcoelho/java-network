-- Insertion des données
insert into TODO (ID_TODO, DESCRIPTION) values (1, 'Faire le TP avec sa tête et ses doigts.');
insert into TODO (ID_TODO, DESCRIPTION) values (2, 'Comprendre (ou presque) ce qui est fait.');
insert into TODO (ID_TODO, DESCRIPTION) values (3, 'Apprécier le résultat.');
