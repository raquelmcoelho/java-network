function descriptionDone() {
    alert("You are unregistered from tournament");
}