
function inscriptionDone() {
    alert("You have been registered successfully to this Tournament");
}
