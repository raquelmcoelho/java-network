package com.example.imageviewer.tennis.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "ActionServlet", value = "/action")
public class ActionServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession(false);
        String code = request.getParameter("code");

        boolean isAuthenticated = (session != null && session.getAttribute("user") != null);

        if (!isAuthenticated) {
            if ("L".equals(code)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("login");
                dispatcher.forward(request, response);
            } else {
                response.sendRedirect("Login.html");
            }
            return;
        }

        switch (code) {
            case "A":
                request.getRequestDispatcher("adherent").forward(request, response);
                break;
            case "I":
                request.getRequestDispatcher("inscription").forward(request, response);
                break;
            default:
                request.getRequestDispatcher("Menu.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
