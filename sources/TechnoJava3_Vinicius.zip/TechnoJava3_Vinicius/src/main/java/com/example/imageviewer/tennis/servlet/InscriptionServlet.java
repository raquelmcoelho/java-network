package com.example.imageviewer.tennis.servlet;

import com.example.imageviewer.tennis.bean.Adherent;
import com.example.imageviewer.tennis.bean.Inscription;
import com.example.imageviewer.tennis.bean.Tournoi;
import jakarta.persistence.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@WebServlet(name = "InscriptionServlet", value = "/inscription")
public class InscriptionServlet extends HttpServlet {
    private EntityManagerFactory emf;

    @Override
    public void init() throws ServletException {
        emf = Persistence.createEntityManagerFactory("tennisPU");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response); // aceita GET também
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Adherent adherent = (Adherent) session.getAttribute("user");

        if (adherent == null) {
            response.sendRedirect("Login.html");
            return;
        }

        String tournoiId = request.getParameter("tournoi");
        EntityManager em = emf.createEntityManager();

        if (tournoiId == null) {
            List<Tournoi> tournois = em.createQuery(
                            "SELECT t FROM Tournoi t WHERE t.codeTournoi NOT IN (" +
                                    "SELECT i.tournoi.codeTournoi FROM Inscription i WHERE i.adherent.numeroAdherent = :id)", Tournoi.class)
                    .setParameter("id", adherent.getNumeroAdherent())
                    .getResultList();
            request.setAttribute("tournois", tournois);
            em.close();
            RequestDispatcher dispatcher = request.getRequestDispatcher("InscriptionTournois.jsp");
            dispatcher.forward(request, response);
        } else {
            Long id = Long.parseLong(tournoiId);
            Tournoi tournoi = em.find(Tournoi.class, id);

            if (tournoi != null) {
                Inscription inscription = new Inscription();
                inscription.setAdherent(adherent);
                inscription.setTournoi(tournoi);
                inscription.setDateInscription(LocalDate.now());

                em.getTransaction().begin();
                em.persist(inscription);
                em.getTransaction().commit();

                request.setAttribute("tournoi", tournoi);
            }

            em.close();
            RequestDispatcher dispatcher = request.getRequestDispatcher("InscriptionStatus.jsp");
            dispatcher.forward(request, response);
        }
    }
}
