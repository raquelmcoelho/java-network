package com.example.imageviewer.tennis.bean;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "inscription")
public class Inscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "numeroadherent", nullable = false)
    private Adherent adherent;

    @ManyToOne
    @JoinColumn(name = "codetournoi", nullable = false)
    private Tournoi tournoi;

    @Column(name = "dateinscription", nullable = false)
    private LocalDate dateInscription;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Adherent getAdherent() {
        return adherent;
    }

    public void setAdherent(Adherent adherent) {
        this.adherent = adherent;
    }

    public Tournoi getTournoi() {
        return tournoi;
    }

    public void setTournoi(Tournoi tournoi) {
        this.tournoi = tournoi;
    }

    public LocalDate getDateInscription() {
        return dateInscription;
    }

    public void setDateInscription(LocalDate dateInscription) {
        this.dateInscription = dateInscription;
    }
}
