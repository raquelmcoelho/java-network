package com.example.imageviewer.tennis.bean;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "tournoi")
public class Tournoi {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codetournoi")
    private Long codeTournoi;

    @Column(nullable = false)
    private String nom;

    @Column(nullable = false)
    private LocalDate date;

    @Column(nullable = false)
    private String lieu;

    public Long getCodeTournoi() {
        return codeTournoi;
    }

    public void setCodeTournoi(Long codeTournoi) {
        this.codeTournoi = codeTournoi;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getLieu() {
        return lieu;
    }

    public void setLieu(String lieu) {
        this.lieu = lieu;
    }
}

