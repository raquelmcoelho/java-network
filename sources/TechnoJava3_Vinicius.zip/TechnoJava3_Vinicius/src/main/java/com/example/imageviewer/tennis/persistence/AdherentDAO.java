package com.example.imageviewer.tennis.persistence;

import com.example.imageviewer.tennis.bean.Adherent;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

public class AdherentDAO {
    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("tennisPU");

    public Adherent findByEmail(String email) {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<Adherent> query = em.createQuery(
                    "SELECT a FROM Adherent a WHERE a.email = :email", Adherent.class);
            query.setParameter("email", email);
            return query.getResultStream().findFirst().orElse(null);
        } finally {
            em.close();
        }
    }
}