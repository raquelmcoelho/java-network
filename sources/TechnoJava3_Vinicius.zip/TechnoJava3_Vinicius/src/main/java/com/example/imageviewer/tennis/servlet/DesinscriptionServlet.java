package com.example.imageviewer.tennis.servlet;

import com.example.imageviewer.tennis.bean.Adherent;
import com.example.imageviewer.tennis.bean.Inscription;

import jakarta.persistence.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "DesinscriptionServlet", value = "/desinscription")
public class DesinscriptionServlet extends HttpServlet {
    private EntityManagerFactory emf;

    @Override
    public void init() throws ServletException {
        emf = Persistence.createEntityManagerFactory("tennisPU");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Adherent adherent = (Adherent) session.getAttribute("user");

        if (adherent == null) {
            response.sendRedirect("Login.html");
            return;
        }

        Long idInscription = Long.parseLong(request.getParameter("id"));
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();
            Inscription inscription = em.find(Inscription.class, idInscription);

            if (inscription != null && inscription.getAdherent().getNumeroAdherent().equals(adherent.getNumeroAdherent())) {
                em.remove(inscription);
            }

            em.getTransaction().commit();
        } finally {
            em.close();
        }

        response.sendRedirect("action?code=A");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
