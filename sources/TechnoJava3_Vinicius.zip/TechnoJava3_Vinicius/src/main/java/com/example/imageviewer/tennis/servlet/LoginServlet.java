package com.example.imageviewer.tennis.servlet;

import com.example.imageviewer.tennis.bean.Adherent;
import com.example.imageviewer.tennis.persistence.AdherentDAO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import com.example.imageviewer.tennis.util.PasswordUtil;

import java.io.IOException;

@WebServlet(name = "LoginServlet", value = "/login")
public class LoginServlet extends HttpServlet {
    private final AdherentDAO dao = new AdherentDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Adherent adherent = dao.findByEmail(email);

        if (adherent != null && adherent.getPassword().equals(PasswordUtil.hash(password))) {
            HttpSession session = request.getSession();
            session.setAttribute("user", adherent);
            RequestDispatcher dispatcher = request.getRequestDispatcher("Menu.jsp");
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect("Login.html");
        }
    }
}
