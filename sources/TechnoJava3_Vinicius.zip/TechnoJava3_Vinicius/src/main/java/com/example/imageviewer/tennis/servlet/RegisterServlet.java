package com.example.imageviewer.tennis.servlet;

import com.example.imageviewer.tennis.bean.Adherent;
import com.example.imageviewer.tennis.persistence.AdherentDAO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import com.example.imageviewer.tennis.util.PasswordUtil;

import java.io.IOException;

@WebServlet(name = "RegisterServlet", value = "/register")
public class RegisterServlet extends HttpServlet {
    private EntityManagerFactory emf;

    @Override
    public void init() throws ServletException {
        emf = Persistence.createEntityManagerFactory("tennisPU");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String adresse = request.getParameter("adresse");
        String telephone = request.getParameter("telephone");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        AdherentDAO dao = new AdherentDAO();
        Adherent existing = dao.findByEmail(email);

        if (existing != null) {
            response.sendRedirect("Register.html");
            return;
        }

        Adherent adherent = new Adherent();
        adherent.setNom(nom);
        adherent.setPrenom(prenom);
        adherent.setAdresse(adresse);
        adherent.setTelephone(telephone);
        adherent.setEmail(email);
        adherent.setPassword(PasswordUtil.hash(password));

        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(adherent);
            em.getTransaction().commit();
        } finally {
            em.close();
        }

        response.sendRedirect("Login.html");
    }
}

