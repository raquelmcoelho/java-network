package com.example.imageviewer.tennis.servlet;

import com.example.imageviewer.tennis.bean.Adherent;
import com.example.imageviewer.tennis.bean.Inscription;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdherentServlet", value = "/adherent")
public class AdherentServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Adherent adherent = (Adherent) session.getAttribute("user");

        if (adherent == null) {
            response.sendRedirect("Login.html");
            return;
        }

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("tennisPU");
        EntityManager em = emf.createEntityManager();

        List<Inscription> inscriptions = em.createQuery(
                        "SELECT i FROM Inscription i WHERE i.adherent.numeroAdherent = :id", Inscription.class)
                .setParameter("id", adherent.getNumeroAdherent())
                .getResultList();

        em.close();

        request.setAttribute("adherent", adherent);
        request.setAttribute("inscriptions", inscriptions);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Adherent.jsp");
        dispatcher.forward(request, response);
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
