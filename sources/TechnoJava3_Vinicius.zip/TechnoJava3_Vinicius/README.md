# Tennis Club Web Application
Java Technologies TP3 ENSICAEN <br>
Vinicius Giovani MOREIRA NASCIMENTO  

This is a simple Java web application for managing a tennis club's users and tournaments. It was built using **Servlets**, **JSP**, **Hibernate**, and **Jakarta EE**, following the model-view-controller (MVC) approach. The system allows users to register, log in, view their profile, sign up for tournaments, and cancel their participation.

## 🔧 Setup and Configuration

- **Jakarta EE** is used for the servlet and web components.
- **Hibernate** is configured with `persistence.xml` to handle database operations using JPA.
- The database used is **PostgreSQL**. You need to create a database named `tennis` and update your credentials in the `persistence.xml` file.
- To run the project, we used **Apache Tomcat** and **IntelliJ IDEA** with Jakarta EE and Maven setup.
- Passwords are hashed using **SHA-256** before being stored in the database.

## ▶️ How to Run

1. Clone or import the project into IntelliJ.
2. Make sure PostgreSQL is running and the `tennis` database is created.
3. Deploy the project to Tomcat (local).
4. Access the app at `http://localhost:8080/tennis` (adjust port/project name if needed).
5. Start by creating an account through the "Register" page.

## ⚙️ Features

- Registration and login system with password hashing.
- Users can:
    - View their personal information and tournament registrations.
    - Register for available tournaments.
    - Cancel their registration from a tournament.
- Once registered, tournaments no longer appear in the available list.
- Session management is used to protect access to pages.
- A central `ActionServlet` handles routing between user actions.
- JSP pages are styled with Bootstrap 5.

